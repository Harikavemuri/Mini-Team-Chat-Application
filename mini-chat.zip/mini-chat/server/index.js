import express from 'express';
import http from 'http';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import { PrismaClient } from '@prisma/client';
import { Server } from 'socket.io';
import { v4 as uuidv4 } from 'uuid';
import bodyParser from 'body-parser';
import dotenv from 'dotenv';

dotenv.config();
const prisma = new PrismaClient();
const app = express();
app.use(bodyParser.json());
app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  credentials: true
}));

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: process.env.FRONTEND_URL || '*', methods: ['GET','POST'] }
});

const JWT_SECRET = process.env.JWT_SECRET || 'devsecret';

// --- Helpers ---
function generateToken(user) {
  return jwt.sign({ userId: user.id, email: user.email, name: user.name }, JWT_SECRET, { expiresIn: '7d' });
}

async function authMiddleware(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ error: 'Missing token' });
  const token = auth.split(' ')[1];
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
}

// --- HTTP routes ---
app.post('/api/auth/signup', async (req, res) => {
  const { name, email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Missing fields' });
  const existing = await prisma.user.findUnique({ where: { email }});
  if (existing) return res.status(400).json({ error: 'Email exists' });
  const hash = await bcrypt.hash(password, 10);
  const user = await prisma.user.create({ data: { name, email, passwordHash: hash }});
  const token = generateToken(user);
  res.json({ token, user: { id: user.id, name: user.name, email: user.email }});
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await prisma.user.findUnique({ where: { email }});
  if (!user) return res.status(400).json({ error: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(400).json({ error: 'Invalid credentials' });
  const token = generateToken(user);
  res.json({ token, user: { id: user.id, name: user.name, email: user.email }});
});

app.get('/api/auth/me', authMiddleware, async (req, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.user.userId }});
  res.json({ user: { id: user.id, name: user.name, email: user.email }});
});

// channels
app.get('/api/channels', authMiddleware, async (req, res) => {
  const channels = await prisma.channel.findMany({
    include: { members: true }
  });
  const out = channels.map(c => ({ id: c.id, name: c.name, memberCount: c.members.length }));
  res.json(out);
});

app.post('/api/channels', authMiddleware, async (req, res) => {
  const { name, isPrivate } = req.body;
  const channel = await prisma.channel.create({ data: { name, isPrivate: !!isPrivate, createdBy: req.user.userId }});
  res.json(channel);
});

app.post('/api/channels/:id/join', authMiddleware, async (req, res) => {
  const channelId = req.params.id;
  // upsert membership
  const existing = await prisma.channelMember.findFirst({ where: { channelId, userId: req.user.userId }});
  if (!existing) {
    await prisma.channelMember.create({ data: { channelId, userId: req.user.userId }});
  }
  res.json({ ok: true });
});

app.post('/api/channels/:id/leave', authMiddleware, async (req, res) => {
  const channelId = req.params.id;
  await prisma.channelMember.deleteMany({ where: { channelId, userId: req.user.userId }});
  res.json({ ok: true });
});

// messages with cursor pagination: ?limit=30&before=<timestamp ISO>
app.get('/api/channels/:id/messages', authMiddleware, async (req, res) => {
  const channelId = req.params.id;
  const limit = Math.min(100, Number(req.query.limit) || 30);
  const before = req.query.before ? new Date(req.query.before) : undefined;
  const where = { channelId };
  const msgs = await prisma.message.findMany({
    where: before ? { ...where, createdAt: { lt: before } } : where,
    include: { sender: true },
    orderBy: { createdAt: 'desc' },
    take: limit
  });
  // return in ascending order for UI convenience (oldest first)
  res.json(msgs.reverse());
});

// fallback HTTP send (optional)
app.post('/api/messages', authMiddleware, async (req, res) => {
  const { channelId, content } = req.body;
  const msg = await prisma.message.create({ data: { channelId, senderId: req.user.userId, content }});
  // emit to channel room via io
  io.to(`channel:${channelId}`).emit('message', {
    id: msg.id,
    channelId: msg.channelId,
    senderId: msg.senderId,
    content: msg.content,
    createdAt: msg.createdAt
  });
  res.json(msg);
});

// --- Socket.IO for realtime + presence ---
const userSessions = new Map(); // userId -> Set(sessionIds)

io.use((socket, next) => {
  // expect token in handshake auth
  const token = socket.handshake.auth?.token;
  if (!token) return next(new Error('no token'));
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    socket.userId = payload.userId;
    next();
  } catch (err) {
    next(new Error('invalid token'));
  }
});

io.on('connection', (socket) => {
  const userId = socket.userId;
  const sessionId = socket.handshake.auth.sessionId || uuidv4();

  // track session
  if (!userSessions.has(userId)) userSessions.set(userId, new Set());
  userSessions.get(userId).add(sessionId);

  // broadcast presence: online
  io.emit('presence_update', { userId, isOnline: true });

  socket.on('join_channel', ({ channelId }) => {
    socket.join(`channel:${channelId}`);
    // optionally emit members update
  });

  socket.on('leave_channel', ({ channelId }) => {
    socket.leave(`channel:${channelId}`);
  });

  socket.on('send_message', async ({ channelId, content, tempId }) => {
    if (!content || !channelId) return;
    const msg = await prisma.message.create({
      data: { channelId, senderId: userId, content }
    });
    const payload = {
      id: msg.id,
      channelId: msg.channelId,
      senderId: msg.senderId,
      content: msg.content,
      createdAt: msg.createdAt,
      tempId: tempId || null
    };
    io.to(`channel:${channelId}`).emit('message', payload);
  });

  socket.on('typing', ({ channelId, isTyping }) => {
    socket.to(`channel:${channelId}`).emit('typing', { userId, isTyping });
  });

  socket.on('disconnect', () => {
    const sessions = userSessions.get(userId);
    if (sessions) {
      sessions.delete(sessionId);
      if (sessions.size === 0) {
        userSessions.delete(userId);
        io.emit('presence_update', { userId, isOnline: false });
      }
    }
  });
});

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
