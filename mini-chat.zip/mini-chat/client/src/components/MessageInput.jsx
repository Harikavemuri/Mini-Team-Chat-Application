import React, { useState } from 'react';

export default function MessageInput({ onSend }) {
  const [text, setText] = useState('');
  const submit = (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    onSend(text.trim());
    setText('');
  };
  return (
    <form onSubmit={submit} style={{padding:10, borderTop:'1px solid #ddd'}}>
      <input style={{width:'80%'}} value={text} onChange={e=>setText(e.target.value)} placeholder="Write a message..." />
      <button type="submit">Send</button>
    </form>
  );
}
