import React, { useEffect, useState } from 'react';
import API from '../api';
import { connectSocket } from '../socket';
import MessageList from './MessageList';
import MessageInput from './MessageInput';

export default function ChatView({ channelId, token, user }) {
  const [messages, setMessages] = useState([]);
  const [socket, setSocket] = useState(null);
  const [hasMore, setHasMore] = useState(true);

  useEffect(() => {
    if (!channelId) return;
    (async () => {
      const r = await API.get(`/channels/${channelId}/messages?limit=30`);
      setMessages(r.data);
      setHasMore(r.data.length >= 30);
    })();
  }, [channelId]);

  useEffect(() => {
    if (!token) return;
    const s = connectSocket(token);
    setSocket(s);

    s.on('message', (msg) => {
      if (msg.channelId === channelId) {
        setMessages(m => [...m, msg]);
      }
    });
    return () => {
      if (s && channelId) s.emit('leave_channel', { channelId });
    };
  }, [token, channelId]);

  useEffect(() => {
    if (socket && channelId) {
      socket.emit('join_channel', { channelId });
    }
  }, [socket, channelId]);

  const sendMessage = (content) => {
    const tempId = 't-' + Math.random().toString(36).slice(2,9);
    const tempMsg = { id: tempId, channelId, senderId: user.id, content, createdAt: new Date().toISOString(), temp: true, sender: user };
    setMessages(m => [...m, tempMsg]);
    socket.emit('send_message', { channelId, content, tempId });
  };

  const loadOlder = async () => {
    if (!messages.length) return;
    const oldest = messages[0].createdAt;
    const r = await API.get(`/channels/${channelId}/messages?limit=30&before=${encodeURIComponent(oldest)}`);
    if (r.data.length === 0) setHasMore(false);
    else setMessages(prev => [...r.data, ...prev]);
  };

  return (
    <div style={{flex:1, display:'flex', flexDirection:'column'}}>
      <div style={{padding:10, borderBottom:'1px solid #ddd'}}>
        <h3>Channel: {channelId || '—'}</h3>
        <button onClick={loadOlder} disabled={!hasMore}>Load older</button>
      </div>
      <MessageList messages={messages} />
      <MessageInput onSend={sendMessage} />
    </div>
  );
}
