import React, { useState } from 'react';
import API from '../api';

export default function AuthForm({ onLogin }) {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [mode, setMode] = useState('login');

  async function submit(e) {
    e.preventDefault();
    try {
      if (mode === 'login') {
        const r = await API.post('/auth/login', { email, password });
        onLogin(r.data);
      } else {
        const r = await API.post('/auth/signup', { name, email, password });
        onLogin(r.data);
      }
    } catch (err) {
      alert(err.response?.data?.error || 'Failed');
    }
  }

  return (
    <div style={{margin:'auto',width:360}}>
      <h2>{mode === 'login' ? 'Login' : 'Sign up'}</h2>
      <form onSubmit={submit}>
        {mode === 'signup' && <div>
          <label>Name</label>
          <input value={name} onChange={e=>setName(e.target.value)} required />
        </div>}
        <div>
          <label>Email</label>
          <input value={email} onChange={e=>setEmail(e.target.value)} required />
        </div>
        <div>
          <label>Password</label>
          <input type="password" value={password} onChange={e=>setPassword(e.target.value)} required/>
        </div>
        <button type="submit">{mode === 'login' ? 'Login' : 'Create account'}</button>
      </form>
      <hr />
      <button onClick={() => setMode(mode === 'login' ? 'signup' : 'login')}>
        {mode === 'login' ? "Create account" : "Already have account? Login"}
      </button>
    </div>
  );
}
