import React from 'react';

export default function MessageList({ messages }) {
  return (
    <div style={{flex:1, overflowY:'auto', padding:10}}>
      {messages.map(m => (
        <div key={m.id} style={{marginBottom:8, opacity: m.temp ? 0.6 : 1}}>
          <div style={{fontSize:12, color:'#555'}}>{m.sender?.name || m.senderId} <small>{new Date(m.createdAt).toLocaleTimeString()}</small></div>
          <div style={{padding:'6px 8px', background:'#f7f7f7', borderRadius:6}}>{m.content}</div>
        </div>
      ))}
    </div>
  );
}
