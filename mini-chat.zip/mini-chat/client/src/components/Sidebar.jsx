import React, { useState } from 'react';
import API from '../api';

export default function Sidebar({ channels, setChannels, setCurrentChannel, currentChannel, onLogout }) {
  const [name, setName] = useState('');

  async function createChannel() {
    if (!name) return;
    const r = await API.post('/channels', { name });
    setChannels(prev => [...prev, r.data]);
    setName('');
  }

  return (
    <div style={{width:250, borderRight:'1px solid #ddd', padding:10}}>
      <h3>Channels</h3>
      <ul style={{padding:0}}>
        {channels.map(c => (
          <li key={c.id} style={{listStyle:'none', padding:'6px', cursor:'pointer', background: c.id===currentChannel ? '#eef' : 'transparent'}} onClick={()=>setCurrentChannel(c.id)}>
            #{c.name} <small>({c.memberCount})</small>
          </li>
        ))}
      </ul>
      <div style={{marginTop:10}}>
        <input placeholder="new channel" value={name} onChange={e=>setName(e.target.value)} />
        <button onClick={createChannel}>Create</button>
      </div>
      <div style={{position:'absolute', bottom:20}}>
        <button onClick={onLogout}>Logout</button>
      </div>
    </div>
  );
}
