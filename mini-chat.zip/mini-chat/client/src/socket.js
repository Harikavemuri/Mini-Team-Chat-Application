import { io } from 'socket.io-client';
let socket = null;

export function connectSocket(token) {
  if (socket) return socket;
  const sessionId = sessionStorage.getItem('sessionId') || (() => {
    const s = crypto.randomUUID();
    sessionStorage.setItem('sessionId', s);
    return s;
  })();

  socket = io(import.meta.env.VITE_API_BASE?.replace('/api','') || 'http://localhost:4000', {
    auth: { token, sessionId }
  });
  return socket;
}

export function disconnectSocket() {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
}

export default () => socket;
