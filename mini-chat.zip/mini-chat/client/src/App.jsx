import React, { useEffect, useState } from 'react';
import API, { setAuthToken } from './api';
import { connectSocket, disconnectSocket } from './socket';
import AuthForm from './components/AuthForm';
import Sidebar from './components/Sidebar';
import ChatView from './components/ChatView';

export default function App() {
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [user, setUser] = useState(null);
  const [channels, setChannels] = useState([]);
  const [currentChannel, setCurrentChannel] = useState(null);

  useEffect(() => {
    if (token) {
      setAuthToken(token);
      API.get('/auth/me').then(r => {
        setUser(r.data.user);
        connectSocket(token);
      }).catch(() => {
        logout();
      });
      loadChannels();
    } else {
      setUser(null);
      disconnectSocket();
    }
  }, [token]);

  async function loadChannels() {
    const res = await API.get('/channels');
    setChannels(res.data);
    if (!currentChannel && res.data.length) setCurrentChannel(res.data[0].id);
  }

  function onLogin({ token, user }) {
    localStorage.setItem('token', token);
    setAuthToken(token);
    setToken(token);
    setUser(user);
  }

  function logout() {
    localStorage.removeItem('token');
    setAuthToken(null);
    setToken(null);
    setUser(null);
  }

  return (
    <div style={{display:'flex',height:'100vh'}}>
      {token && user ? (
        <>
          <Sidebar channels={channels} setChannels={setChannels} setCurrentChannel={setCurrentChannel} currentChannel={currentChannel} onLogout={logout} />
          <ChatView channelId={currentChannel} token={token} user={user} />
        </>
      ) : (
        <AuthForm onLogin={onLogin} />
      )}
    </div>
  );
}
