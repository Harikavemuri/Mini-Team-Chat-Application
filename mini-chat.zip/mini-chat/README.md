# Mini Team Chat Application

This is the full scaffold for the Mini Team Chat app (backend + frontend).
Follow the instructions in server/ and client/ folders to run locally.
